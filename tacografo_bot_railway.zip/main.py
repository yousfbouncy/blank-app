import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from datetime import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials

# TOKEN del bot de Telegram
TOKEN = "7388552716:AAGRBVsA5iproVfk9m1pGjwmhm65PNtzLeo"

# Nombre de la hoja de Google Sheets
GOOGLE_SHEET_NAME = "Registro Tacógrafo"

# Configurar conexión con Google Sheets
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
client = gspread.authorize(creds)
sheet = client.open(GOOGLE_SHEET_NAME).sheet1

# Función para registrar datos
def registrar_en_hoja(actividad, usuario):
    fecha = datetime.now().strftime("%d/%m/%Y")
    hora = datetime.now().strftime("%H:%M")
    sheet.append_row([fecha, hora, actividad, usuario])

# /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("🟢 Conducción", callback_data='🟢 Conducción')],
        [InlineKeyboardButton("🔴 Descanso", callback_data='🔴 Descanso')],
        [InlineKeyboardButton("🟡 Otro trabajo", callback_data='🟡 Otro trabajo')],
        [InlineKeyboardButton("🔵 Disponibilidad", callback_data='🔵 Disponibilidad')],
        [InlineKeyboardButton("📦 Cargando", callback_data='📦 Cargando')],
        [InlineKeyboardButton("📤 Descargando", callback_data='📤 Descargando')],
        [InlineKeyboardButton("🛑 Fin de jornada", callback_data='🛑 Fin de jornada')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Selecciona una actividad:", reply_markup=reply_markup)

# Manejo de botones
async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    actividad = query.data
    usuario = query.from_user.first_name
    registrar_en_hoja(actividad, usuario)
    await query.edit_message_text(text=f"✅ Actividad registrada: {actividad}")

# Main
def main():
    logging.basicConfig(level=logging.INFO)
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button))
    app.run_polling()

if __name__ == "__main__":
    main()
